"""Phase 22/23 — Pydantic schemas for the Shopkeeper App API."""

from datetime import datetime

from pydantic import BaseModel, Field, field_validator
import re


# ── Auth ─────────────────────────────────────────────────────────────────
class ShopkeeperSendOTPRequest(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=20)


class ShopkeeperRegisterRequest(BaseModel):
    """First-time shopkeeper registration.

    Phone verification is performed client-side by Firebase Phone Auth — the
    Flutter app sends the resulting Firebase ID token (``firebase_id_token``).
    The backend verifies the token to extract and trust the phone number.
    """

    firebase_id_token: str = Field(
        ...,
        min_length=20,
        description="Firebase ID token from a completed phone-OTP sign-in",
    )
    phone_number: str = Field(..., min_length=10, max_length=20, description="Must match the token's phone")
    name: str = Field(..., min_length=1, max_length=100)
    email: str | None = Field(None, max_length=255)
    password: str = Field(..., min_length=8, max_length=128, description="Password (8+ chars)")
    device_id: str | None = Field(None, description="Stable device identifier")
    device_name: str | None = None
    device_type: str | None = Field(None, description="android, ios, web")
    platform: str | None = None
    app_version: str | None = None

    @field_validator('password')
    @classmethod
    def validate_password(cls, v):
        """Validate password strength."""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not re.search(r'[A-Za-z]', v):
            raise ValueError('Password must contain at least one letter')
        if not re.search(r'[0-9]', v):
            raise ValueError('Password must contain at least one number')
        return v


class ShopkeeperLoginRequest(BaseModel):
    """Password-based login for shopkeeper (identifier can be email or phone)."""

    identifier: str = Field(..., min_length=3, max_length=255, description="Email or phone number")
    password: str = Field(..., min_length=8, max_length=128)
    device_id: str | None = None
    device_name: str | None = None
    device_type: str | None = None
    platform: str | None = None
    app_version: str | None = None


class ShopkeeperOTPLoginRequest(BaseModel):
    """Firebase-phone-OTP login for an EXISTING account via the Shopkeeper App.

    The Flutter app completes the OTP flow client-side with ``firebase_auth``
    and sends the resulting Firebase ID token (``firebase_id_token``).
    """

    firebase_id_token: str = Field(
        ...,
        min_length=20,
        description="Firebase ID token from a completed phone-OTP sign-in",
    )
    device_id: str | None = None
    device_name: str | None = None
    device_type: str | None = None
    platform: str | None = None
    app_version: str | None = None


class ShopkeeperFirebaseLoginRequest(BaseModel):
    """Combined Firebase login-or-register request.

    The Flutter app sends the Firebase ID token after a successful phone-OTP
    sign-in. The backend verifies the token, extracts the phone number, and
    either logs in an existing shopkeeper or auto-registers a new one (if no
    account exists for that phone). This "login or register on first use" flow
    is the standard pattern for phone-auth apps.
    """

    firebase_id_token: str = Field(
        ...,
        min_length=20,
        description="Firebase ID token from a completed phone-OTP sign-in",
    )
    name: str | None = Field(None, max_length=100, description="Required only when auto-registering a new account")
    device_id: str | None = Field(None, description="Stable device identifier")
    device_name: str | None = None
    device_type: str | None = Field(None, description="android, ios, web")
    platform: str | None = None
    app_version: str | None = None


class ShopkeeperRefreshRequest(BaseModel):
    refresh_token: str
    device_id: str | None = None


class ShopkeeperLogoutRequest(BaseModel):
    refresh_token: str | None = None
    session_id: str | None = None
    revoke_all: bool = False


class ShopkeeperForgotPasswordRequest(BaseModel):
    """Request password reset (identifier can be email or phone)."""

    identifier: str = Field(..., min_length=3, max_length=255, description="Email or phone number")


class ShopkeeperResetPasswordRequest(BaseModel):
    """Reset password using token from forgot-password email/SMS."""

    token: str = Field(..., description="Password reset token")
    new_password: str = Field(..., min_length=8, max_length=128, description="New password")

    @field_validator('new_password')
    @classmethod
    def validate_password(cls, v):
        """Validate password strength."""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not re.search(r'[A-Za-z]', v):
            raise ValueError('Password must contain at least one letter')
        if not re.search(r'[0-9]', v):
            raise ValueError('Password must contain at least one number')
        return v


# ── Token Response ──────────────────────────────────────────────────────────
class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    session_id: str | None = None


class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    session_id: str | None = None
    user: dict
    shops: list[dict] = []


# ── Shop registration / profile / settings ───────────────────────────────
class ShopAddressInput(BaseModel):
    address_line1: str = Field(..., min_length=1, max_length=255)
    address_line2: str | None = Field(None, max_length=255)
    landmark: str | None = Field(None, max_length=255)
    city: str = Field(..., min_length=1, max_length=100)
    state: str = Field(..., min_length=1, max_length=100)
    pincode: str = Field(..., min_length=3, max_length=10)
    country: str | None = Field("India", max_length=100)


# ── Location capture metadata (Phase: Shop Location System) ─────────────────
class ShopLocationMeta(BaseModel):
    """Provenance/quality metadata for a captured shop location.

    GPS coordinates remain the primary source of truth; this block is
    supporting metadata used by admin review and accuracy auditing.
    """

    location_source: str | None = Field(
        None, max_length=20, description="GPS | MANUAL | ADDRESS"
    )
    location_type: str | None = Field(
        None, max_length=30, description="SHOP_ENTRANCE | BUILDING_CENTER | OTHER"
    )
    location_status: str | None = Field(
        None, max_length=20, description="CAPTURED | CONFIRMED | CORRECTED | STALE"
    )
    location_integrity_status: str | None = Field(
        None, max_length=20, description="NORMAL | SUSPICIOUS | UNKNOWN"
    )
    accuracy_meters: float | None = Field(None, ge=0, le=10000)
    location_captured_at: datetime | None = Field(
        None, description="Device timestamp of the fix (ISO-8601, UTC)"
    )
    location_verified: bool | None = Field(
        None, description="Shopkeeper confirmed the pin at the access point"
    )


class ShopkeeperShopCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    tagline: str | None = Field(None, max_length=255)
    category: str | None = Field(None, max_length=50)
    phone: str | None = Field(None, max_length=20)
    whatsapp_number: str | None = Field(None, max_length=20)
    email: str | None = Field(None, max_length=255)
    image_url: str | None = Field(None, max_length=500)
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    gstin: str | None = Field(None, max_length=50)
    address: ShopAddressInput
    # Optional capture provenance — populated by the shopkeeper location flow.
    location: ShopLocationMeta | None = None


class ShopkeeperShopLocationUpdate(BaseModel):
    """Controlled, IDOR-safe edit of a shop's location.

    Only ``latitude``/``longitude`` are required; the remaining fields are
    accepted so the controlled Edit-Location flow can persist the new
    accuracy/timestamp/source in a single request.
    """

    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    location: ShopLocationMeta | None = None


class ShopkeeperProfileUpdate(BaseModel):
    """Editable shop profile fields (whitelist enforced in service)."""

    name: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = None
    tagline: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=20)
    alternate_phone: str | None = Field(None, max_length=20)
    whatsapp_number: str | None = Field(None, max_length=20)
    email: str | None = Field(None, max_length=255)
    website_url: str | None = Field(None, max_length=500)
    image_url: str | None = Field(None, max_length=500)
    logo_url: str | None = Field(None, max_length=500)
    # Phase 7 — signed-upload integration: pass the server-minted object key
    # returned by POST /media/confirm. Validated (category + ownership +
    # existence) and converted to a durable s3:// storage reference.
    image_key: str | None = Field(None, max_length=512)
    logo_key: str | None = Field(None, max_length=512)


class ShopkeeperSettingsUpdate(BaseModel):
    """Operational settings toggles for a shop."""

    is_accepting_orders: bool | None = None
    is_delivery_available: bool | None = None
    is_pickup_available: bool | None = None
    is_open_24x7: bool | None = None
    min_order_amount: float | None = Field(None, ge=0)
    delivery_radius_km: float | None = Field(None, ge=0, le=100)
    delivery_fee: float | None = Field(None, ge=0)
    free_delivery_above: float | None = Field(None, ge=0)


# ── Products ─────────────────────────────────────────────────────────────
class ShopkeeperProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    brand_name: str | None = Field(None, max_length=120)
    unit: str | None = Field(None, max_length=50)
    price: float = Field(..., ge=0)
    mrp: float | None = Field(None, ge=0)
    sku: str | None = Field(None, max_length=100)
    quantity: int = Field(0, ge=0)
    low_stock_threshold: int = Field(5, ge=0)
    is_available: bool = True
    publish: bool = Field(False, description="Publish immediately (APPROVED) vs keep as DRAFT")
    # Phase 7 — PRODUCT_IMAGE object key from POST /media/confirm.
    image_key: str | None = Field(None, max_length=512)


class ShopkeeperProductUpdate(BaseModel):
    price: float | None = Field(None, ge=0)
    mrp: float | None = Field(None, ge=0)
    quantity: int | None = Field(None, ge=0)
    low_stock_threshold: int | None = Field(None, ge=0)
    is_available: bool | None = None
    is_featured: bool | None = None
    status: str | None = Field(None, max_length=30)
    # Phase 7 — replace the product image with a confirmed PRODUCT_IMAGE key.
    image_key: str | None = Field(None, max_length=512)


# ── Phase 23 — Inventory management ──────────────────────────────────────
class ShopkeeperAddFromMaster(BaseModel):
    """Add an EXISTING product-master record (optionally a variant) to a shop.

    Shopkeepers must select from the platform catalog — arbitrary duplicate
    product-master creation is not allowed through this endpoint.
    """

    product_master_id: int
    variant_id: int | None = None
    price: float = Field(..., ge=0, description="Shop selling price")
    mrp: float | None = Field(None, ge=0)
    sku: str | None = Field(None, max_length=100)
    quantity: int = Field(0, ge=0)
    low_stock_threshold: int = Field(5, ge=0)
    is_available: bool = True


class ShopkeeperStockAdjustment(BaseModel):
    """Delta stock adjustment with audit trail (type + reason)."""

    adjustment_type: str = Field("CORRECTION", max_length=50)
    quantity_adjustment: int = Field(
        ..., description="Delta units (+restock / -damage); result must stay >= 0"
    )
    reason: str | None = Field(None, max_length=255)


class ShopkeeperBulkOperation(BaseModel):
    """Bulk operations foundation: apply one change to many shop products."""

    operation: str = Field(..., description="price_update | stock_set | availability")
    shop_product_ids: list[int] = Field(..., min_length=1, max_length=200)
    price: float | None = Field(None, ge=0)
    mrp: float | None = Field(None, ge=0)
    quantity: int | None = Field(None, ge=0)
    is_available: bool | None = None


class ShopkeeperOfferAssign(BaseModel):
    """Assign (create + link) an offer to selected shop products."""

    title: str = Field(..., min_length=1, max_length=255)
    offer_type: str = Field(..., max_length=40)
    discount_value: float | None = Field(None, ge=0)
    discount_percentage: float | None = Field(None, gt=0, le=100)
    start_date: datetime
    end_date: datetime
    shop_product_ids: list[int] = Field(..., min_length=1, max_length=200)
    terms_conditions: str | None = None
