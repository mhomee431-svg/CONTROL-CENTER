"""Password reset service — forgot password, reset password, and password validation."""
import hashlib
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.exceptions import (
    AppError,
    NotFoundError,
    UnauthorizedError,
    ValidationError,
)
from app.core.security import (
    create_password_reset_token,
    hash_password,
    verify_password,
)
from app.models.user import User, UserStatus

logger = logging.getLogger("app.services.password")

# In-memory store for password reset cooldowns (use Redis in production)
_reset_cooldowns: dict[str, datetime] = {}


def _normalize_identifier(identifier: str) -> str:
    """Normalize email or phone identifier."""
    identifier = identifier.strip().lower()
    if "@" in identifier:
        return identifier
    if identifier.startswith("+"):
        return "+" + "".join(c for c in identifier[1:] if c.isdigit())
    return "".join(c for c in identifier if c.isdigit())


def _hash_reset_token(token: str) -> str:
    """SHA-256 hash of a reset token for storage."""
    return hashlib.sha256(token.encode()).hexdigest()


def request_password_reset(db: Session, identifier: str) -> dict:
    """Request a password reset for the given identifier (email or phone).
    
    Returns a dict with reset info. In production, this would send an email/SMS.
    For development, we return the token directly.
    """
    normalized = _normalize_identifier(identifier)
    
    # Check cooldown to prevent abuse
    cooldown_key = f"reset:{normalized}"
    last_request = _reset_cooldowns.get(cooldown_key)
    if last_request:
        elapsed = (datetime.now(timezone.utc) - last_request).total_seconds()
        if elapsed < settings.PASSWORD_RESET_COOLDOWN_SECONDS:
            raise AppError(
                message="Please wait before requesting another reset",
                error_code="RESET_COOLDOWN",
                status_code=429,
                data={"retry_after_seconds": int(settings.PASSWORD_RESET_COOLDOWN_SECONDS - elapsed)},
            )
    
    # Find user by email or phone
    user = (
        db.query(User).filter(
            (User.email == normalized) | (User.phone_number == normalized)
        ).first()
    )
    
    # Don't reveal if user exists — return generic response
    if user is None:
        logger.info("Password reset requested for non-existent identifier: %s", normalized)
        return {
            "message": "If an account exists, a reset link has been sent",
            "sent": True,
        }
    
    # Check account status
    if user.status in (UserStatus.SUSPENDED, UserStatus.BANNED):
        logger.info("Password reset blocked for inactive user: %s", user.id)
        return {
            "message": "If an account exists, a reset link has been sent",
            "sent": True,
        }
    
    # Generate reset token
    token, jti = create_password_reset_token(
        subject=str(user.id),
        expires_minutes=settings.PASSWORD_RESET_TOKEN_EXPIRE_MINUTES,
    )
    
    # Update cooldown
    _reset_cooldowns[cooldown_key] = datetime.now(timezone.utc)
    
    # In production: send email/SMS with token
    # For development: log and return
    logger.info(
        "Password reset token for user %s: %s (expires in %d minutes)",
        user.id, token, settings.PASSWORD_RESET_TOKEN_EXPIRE_MINUTES,
    )
    
    return {
        "message": "If an account exists, a reset link has been sent",
        "sent": True,
        "token": token if not settings.is_production else None,
    }


def reset_password(db: Session, token: str, new_password: str) -> dict:
    """Reset password using a valid reset token."""
    from app.core.security import decode_token, get_token_subject, validate_token_type, TokenPurpose
    
    # Validate token
    try:
        payload = decode_token(token)
    except Exception:
        raise UnauthorizedError("Invalid or expired reset token")
    
    # Check token type
    if not validate_token_type(token, TokenPurpose.PASSWORD_RESET):
        raise UnauthorizedError("Invalid token type")
    
    # Get user from token
    user_id = get_token_subject(token)
    if user_id is None:
        raise UnauthorizedError("Invalid reset token")
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise NotFoundError("User not found")
    
    # Check account status
    if user.status in (UserStatus.SUSPENDED, UserStatus.BANNED):
        raise UnauthorizedError("Account is not active")
    
    # Validate new password
    if len(new_password) < settings.PASSWORD_MIN_LENGTH:
        raise ValidationError(f"Password must be at least {settings.PASSWORD_MIN_LENGTH} characters")
    
    # Hash and set new password
    user.password_hash = hash_password(new_password)
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    
    logger.info("Password reset successful for user %s", user.id)
    
    return {
        "message": "Password has been reset successfully",
        "success": True,
    }


def change_password(
    db: Session,
    user: User,
    current_password: str,
    new_password: str,
) -> dict:
    """Change password (requires current password)."""
    # Verify current password
    if not user.password_hash:
        raise ValidationError("No password set for this account")
    
    if not verify_password(current_password, user.password_hash):
        raise UnauthorizedError("Current password is incorrect")
    
    # Validate new password
    if len(new_password) < settings.PASSWORD_MIN_LENGTH:
        raise ValidationError(f"Password must be at least {settings.PASSWORD_MIN_LENGTH} characters")
    
    # Hash and set new password
    user.password_hash = hash_password(new_password)
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    
    logger.info("Password changed for user %s", user.id)
    
    return {
        "message": "Password changed successfully",
        "success": True,
    }